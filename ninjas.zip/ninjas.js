$(document).ready (function () {
    $('img').click (function () {
        $(this).fadeOut ('slow', function () {
            $(this).css('visibility', 'hidden');
            $(this).css('display','inline');
        });
    })
    $('button').click (function () {
        $('img').css('visibility', 'visible');
    })
})